# server-screen_recorder
 server-screen_recorder for raspberry pi 3
# pip install pyautogui pillow
# pip install opencv-python-headless numpy
# pip install flask
# sudo apt update
# sudo apt upgrade
# sudo apt install ff


